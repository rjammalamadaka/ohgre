ohgrePortal.controller('ApplePromotionContentController', ['$scope', '$rootScope', '$http',function ($scope, $rootScope,$http) {

       var promoInfo=ohgre.store("promoCodeInfo");
    var portalname=$("#primary-header").data("portalname");

//console.log("YYYY");
    if(promoInfo.LDCList.length>0){
       // console.log("XXXX");
        var ldc=promoInfo.LDCList[0];
        var ldcCode=ldc.LDCCode;
        var promotion=ldc.promotion[0];
      // console.log(promotion.PromotionCode);
         var url="/bin/getQuotes?portalName="+portalname;
		if(ldcCode){
			 url=url+"&ldcCode="+ldcCode;
        }
		 if(promotion && promotion.PromotionCode){
			url=url+"&promotionCode="+promotion.PromotionCode;
        }

        $http.get(url).success(function(data, status, headers, config){
            console.log(data);
            if(data && data.responseStatus =="0"){
				var customer=data.Customer[0];
               $scope.productList= customer.Product;
              //  console.log(product);

            }

        }).error(function (data,status, headers, config){

             console.log("error");
         });

    }



}]);

