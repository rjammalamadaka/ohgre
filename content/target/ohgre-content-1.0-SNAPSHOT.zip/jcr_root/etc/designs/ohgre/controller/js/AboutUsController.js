ohgrePortal.controller('AboutUsController', ['$scope', '$rootScope', '$http',function ($scope, $rootScope,$http) {


}]);

