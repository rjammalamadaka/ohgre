ohgrePortal.controller('WhatIsChoiceController', ['$scope', '$rootScope', '$http',function ($scope, $rootScope,$http) {


}]);

