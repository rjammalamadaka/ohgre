ohgrePortal.controller('PromoCodeController', ['$scope', '$rootScope', '$http',function ($scope, $rootScope,$http) {


 var config = {
		        responsetype : 'json',
        		headers : {
            		'Content-Type' :'application/json'
        		}
   		 }

 var portalname=$("#primary-header").data("portalname");

    var portalRootUrl=null;
    if(portalname =="oh"){
		portalRootUrl ="/content/onlyong/";
    }else if(portalname =="gre"){
		portalRootUrl ="/content/gre/";
    }

    $scope.promoCodeSubmit = function(){


        var promotionCode=$scope.promotionCode;
        var url=null;
        if(promotionCode){
            getPromoGroups(promotionCode);
			 url="/bin/getPromoCodeInfo?portalName="+portalname+"&promotionCode="+promotionCode;
             $http.get(url).success(function(data, status, headers, config){


                 console.log($scope.promoInfo);
var redirectUrl="";
                 if($scope.promoInfo && $scope.promoInfo.url){
					redirectUrl=$scope.promoInfo.url;
                 }else{
					redirectUrl="";
                 }

                 if(data && data.responseStatus =="0"){

                     if(data.LDCList && (data.LDCList.length ==1)){
                         ohgre.store("promoCodeInfo",data);
						location.href=redirectUrl+".html";

                     }else if(data.LDCList.length ==4){
                         ohgre.store("promoCodeInfo",data);
						location.href=redirectUrl+".html";

                     }

                 }else if(data && data.responseStatus =="1"){
						$scope.serverError=data.responsemessage;

                 }

               /*  if(data.promotype =="APPLE"){
                    window.location=portalRootUrl+"promo-landing-apples.html";

                 }else if(data.promotype =="RAF"){

                      window.location=portalRootUrl+"raf-promotion.html";

                 }else if(data.promotype =="DELTA"){

                      window.location=portalRootUrl+"promo_landing.html";

                 }else if(data.promotype =="INVALID"){


                 }*/
             }).error(function (data,status, headers, config){

                 console.log("error");
             });

             }

    }
    var getPromoGroups= function(promotionCode){
			var url='/content/onlyong/promotions.infinity.json';

        $http.get(url).success(function(data, status, headers, config){
            for (var property in data) {
    			if (data.hasOwnProperty(property) && property != "jcr:primaryType") {
                    var childNode=data[property];
                    for(var childproperty in childNode){
                        if(childNode.hasOwnProperty(childproperty) && childproperty != "jcr:primaryType"){
                            var url=childNode[childproperty];

                            if(childproperty == promotionCode){
							var promoinfo={};
							promoinfo.code=childproperty;
                            promoinfo.url=url;
                            $scope.promoInfo=promoinfo;
                                break;
                            }
                        }
                    }
    			}
			}

        }).error(function (data,status, headers, config){

                 console.log("error");
         });


    }

    $scope.signup=function(product){

        var url='/bin/setProductData';
        var req={};
        req.QuoteDescription=product.QuoteDescription;
		req.ProductDescription=product.ProductDescription;
        req.ProductCode=product.ProductCode;
        if($scope.Customer && $scope.Customer.length>0){
        req.LDC=$scope.Customer[0].LDC;
        }
       // var req=JSON.stringify(product);
         $http.post(url, req ,config).success(function(data, status, headers, config){



        		var ldc=$scope.Customer[0].LDC;
				location.href="/content/ohgre/customerenroll.html#pcode="+product.ProductCode+"&ldc="+ldc;


             console.log("success");

         }).error(function (data,status, headers, config){

             console.log("error");
         });


    }

}]);

