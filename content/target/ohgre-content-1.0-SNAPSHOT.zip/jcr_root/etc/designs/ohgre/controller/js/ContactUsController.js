ohgrePortal.controller('ContactUsController', ['$scope', '$rootScope', '$http',function ($scope, $rootScope,$http) {


}]);

