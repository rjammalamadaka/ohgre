ohgrePortal.controller('PromoHeroBannerController', ['$scope', '$rootScope', '$http',function ($scope, $rootScope,$http) {

      var promoInfo=ohgre.store("promoCodeInfo");
    console.log(promoInfo);
    if(promoInfo.LDCList.length>0){
        var ldc=promoInfo.LDCList[0];
        //console.log(ldc.promotion[0]);
        $scope.promotion=ldc.promotion[0];
         //var expdate=$scope.promotion.PromotionExpiratonDate;

        var date = new Date($scope.promotion.PromotionExpiratonDate),
       locale = "en-us",
       month = date.toLocaleString(locale, { month: "long" });
        $scope.expdate=month+" "+date.getDate()+" ,"+date.getFullYear();

    }

}]);

