ohgrePortal.controller('PromotionContentController', ['$scope', '$rootScope', '$http',function ($scope, $rootScope,$http) {


}]);

